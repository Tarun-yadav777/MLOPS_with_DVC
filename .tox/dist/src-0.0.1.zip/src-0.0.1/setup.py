from setuptools import setup, find_packages

setup(
    name="src",
    version="0.0.1",
    description="Its a MLops Package",
    author="Tarun",
    packages=find_packages(),
    license="MIT License"
)

